
#!/bin/bash

# Define paths and settings
BOT_DIR="/home/u234648537/domains/muradtadesse.com/public_html/tiktok_bot"
LOG_FILE="$BOT_DIR/bot.log"
LOCK_FILE="$BOT_DIR/bot.lock"
BOT_SCRIPT="demo_bot.py"  # Using demo_bot.py as it's simpler

# Change to the bot directory
cd "$BOT_DIR"

# Check for a running bot
if [ -f "$LOCK_FILE" ]; then
    PID=$(cat "$LOCK_FILE")
    if ps -p "$PID" > /dev/null; then
        echo "Bot is already running with PID $PID"
        exit 1
    else
        echo "Removing stale lock file"
        rm "$LOCK_FILE"
    fi
fi

# Set up environment
export PATH=$PATH:$HOME/.local/bin

# Start the bot
echo "Starting the bot..."
nohup python3 "$BOT_SCRIPT" > "$LOG_FILE" 2>&1 &
BOT_PID=$!

# Save the PID to the lock file
echo $BOT_PID > "$LOCK_FILE"

echo "Bot started with PID $BOT_PID, log file at $LOG_FILE"
