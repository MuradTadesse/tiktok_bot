#!/bin/bash

case "$1" in
  start)
    cd /home/u234648537/domains/muradtadesse.com/public_html/tiktok_bot
    export PATH=$PATH:$HOME/.local/bin
    pkill -f "python3 demo_bot.py" > /dev/null 2>&1 || true
    sleep 2
    nohup python3 demo_bot.py > bot.log 2>&1 &
    echo "Bot started"
    ;;
  stop)
    pkill -f "python3 demo_bot.py" > /dev/null 2>&1 || true
    echo "Bot stopped"
    ;;
  restart)
    $0 stop
    sleep 2
    $0 start
    ;;
  status)
    if pgrep -f "python3 demo_bot.py" > /dev/null; then
      echo "Bot is running"
    else
      echo "Bot is not running"
    fi
    ;;
  logs)
    tail -f /home/u234648537/domains/muradtadesse.com/public_html/tiktok_bot/bot.log
    ;;
  *)
    echo "Usage: $0 {start|stop|restart|status|logs}"
    exit 1
    ;;
esac
