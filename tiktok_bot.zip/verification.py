
#!/usr/bin/env python
# -*- coding: utf-8 -*-



import os
import re
import logging
from PIL import Image
import io

logger = logging.getLogger(__name__)

class VerificationSystem:
    """System for verifying that users have completed the reporting process."""
    
    def __init__(self, db):
        """Initialize the verification system."""
        self.db = db
        self.verification_folder = "verification_images"
        
        # Create the verification folder if it doesn't exist
        if not os.path.exists(self.verification_folder):
            os.makedirs(self.verification_folder)
        
        # Check if OCR is available
        self.ocr_available = False
        try:
            # We'll attempt to import pytesseract but handle the case if it fails
            import pytesseract
            self.pytesseract = pytesseract
            
            # Try to validate that tesseract is actually available
            pytesseract.get_tesseract_version()
            self.ocr_available = True
            logger.info("OCR is available and working")
        except (ImportError, Exception) as e:
            logger.warning(f"OCR is not available: {e}")
            logger.info("Falling back to text-based verification only")
    
    def validate_screenshot(self, photo_file, target_username):
        """Validate a screenshot using OCR to check if it shows a report confirmation.
        
        If OCR is not available, returns a default message instructing the user to use
        text-based verification instead.
        """
        if not self.ocr_available:
            # OCR not available, return a fallback result
            return {
                'verified': False,
                'confidence': 0,
                'message': "Screenshot verification is not available. Please confirm by typing: "
                          f"I reported {target_username} for harmful content"
            }
        
        try:
            # Convert the photo file to an image
            image = Image.open(photo_file)
            
            # Use OCR to extract text from the image
            extracted_text = self.pytesseract.image_to_string(image)
            
            # Save the image for review (with username and timestamp)
            timestamp = int(time.time())
            image_path = os.path.join(self.verification_folder, f"{target_username}_{timestamp}.jpg")
            image.save(image_path)
            
            # Check if the text contains common phrases from report confirmation screens
            confirmation_phrases = [
                "report", "submitted", "thank you", "thanks for reporting",
                "we've received", "we have received", "reported", 
                f"{target_username}", "account", "review"
            ]
            
            # Count how many phrases were found
            matches = sum(1 for phrase in confirmation_phrases if phrase.lower() in extracted_text.lower())
            confidence = matches / len(confirmation_phrases)
            
            # If enough matches were found, consider it verified
            verified = confidence > 0.3
            
            result = {
                'verified': verified,
                'confidence': confidence,
                'extracted_text': extracted_text,
                'message': "Screenshot verified successfully!" if verified else "Could not verify the screenshot. Please try again or use text verification."
            }
            
            return result
            
        except Exception as e:
            logger.error(f"Error validating screenshot: {e}")
            return {
                'verified': False,
                'confidence': 0,
                'message': f"Error processing screenshot. Please try text verification instead."
            }
    
    def validate_text_confirmation(self, text, target_username):
        """Validate a text confirmation that the user has reported the account."""
        # Normalize text
        text = text.lower().strip()
        
        # Define patterns for valid confirmations
        patterns = [
            r"i\s+reported\s+@?%s" % re.escape(target_username.lower()),
            r"i\s+have\s+reported\s+@?%s" % re.escape(target_username.lower()),
            r"reported\s+@?%s" % re.escape(target_username.lower()),
            r"report\s+@?%s\s+confirmed" % re.escape(target_username.lower()),
            r"i\s+confirm\s+report\w*\s+@?%s" % re.escape(target_username.lower())
        ]
        
        # Check if any of the patterns match
        for pattern in patterns:
            if re.search(pattern, text):
                return {
                    'verified': True,
                    'confidence': 1.0,
                    'message': "Thank you for confirming your report!"
                }
        
        # If no matches, check for partial matches
        if target_username.lower() in text and ("report" in text or "reported" in text):
            return {
                'verified': True,
                'confidence': 0.8,
                'message': "Thank you for confirming your report!"
            }
            
        return {
            'verified': False,
            'confidence': 0,
            'message': f"Could not verify your report. Please type: I reported {target_username} for harmful content"
        }
